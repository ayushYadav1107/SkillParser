# Installing this upgrade

Unpack the archive over the repository root — it only adds files and replaces the
six listed below.

```bash
cd "C:\college stuff\3rd Year\NLP"
tar xzf _skillparser-upgrade.tgz
node scripts/setup-eval.mjs
npm install
```

Then verify, in this order:

```bash
npm run eval:test         # 100 offline assertions — no network, no API key
npm run eval:corpus       # regenerate 60 records × 4 conditions
npm run eval              # run the configured arms, rebuild the report and /eval
npm run typecheck
npm run build
npm run dev               # visit http://localhost:9002/eval
```

`npm run eval` skips any arm whose API key is missing and says so, so it produces a
complete report from the offline arms alone.

## Files replaced

| File | Change |
|---|---|
| `src/ai/genkit.ts` | Hardcoded API key removed; retry helper gains an optional options bag. **Original one-argument behaviour is unchanged.** |
| `src/ai/flows/extract-resume-information-flow.ts` | Now a thin adapter over the shared provider layer. Still registered as a Genkit flow. Output shape is a superset of the old one. |
| `src/app/api/extract-resume/route.ts` | Returns telemetry (`meta`) alongside the data. |
| `src/lib/api-client.ts` | Types the new response; `extractResume` takes an optional `{ useFewShot }`. |
| `README.md` | Rewritten. The unverified "99%+ extraction accuracy" claim is gone. |
| `.gitignore` | Extended by `scripts/setup-eval.mjs`. |

Nothing else in `src/` is touched. `src/lib/types.ts`, `src/app/analyzer/page.tsx`
and `src/hooks/use-talent-pool.ts` keep working unchanged because the four original
schema fields are unchanged — `personal` and `confidence` are additive.

## Before pushing

**Rotate the Gemini API key.** It is in this repository's public git history at
`src/ai/genkit.ts`. Deleting the line does not revoke it:
<https://aistudio.google.com/apikey>. Put the new one in `.env` as `GEMINI_API_KEY`.

Your working tree currently shows every file as modified — that is a CRLF/LF line
ending difference, not real content. Consider `git config core.autocrlf true` and a
`.gitattributes` before committing, or the diff for this change will be impossible
to review.

## Running the real provider arms

Neither the sandbox nor the Cowork device bridge could reach
`generativelanguage.googleapis.com` or `api.groq.com`, so only the offline arms have
actually been run. With keys in `.env`:

```bash
npm run eval -- --arms=heuristic,gemini-zero-shot,gemini-few-shot,groq-few-shot
```

Start with `--condition=primary --limit=20` to check the wiring before spending the
full budget. Responses are cached, so re-running after a change to the *metrics*
costs nothing.

For the scanned conditions on the Groq path you also need OCR:

```bash
npm install tesseract.js
```

Without it those documents are recorded as skipped rather than scored as zeros, and
the report says so.
